package com.onlineshoemart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineshoemartApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineshoemartApplication.class, args);
	}

}
